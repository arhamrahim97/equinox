<?php

return [
    'title' => 'Tambah MOU',
    'subTitle' => 'MOU',
    'category' => 'MOU',
    'content' => 'MOU',

    'card-title' => 'Formulir MOU',
    'card-category' => 'Silakan lengkapi semua informasi di bawah ini untuk membuat MOU'



];