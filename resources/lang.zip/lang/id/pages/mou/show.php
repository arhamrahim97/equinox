<?php

return [
    'title' => 'Lihat MOU',
    'subTitle' => 'MOU',
    'category' => 'MOU',
    'content' => 'MOU',

    // 'card-title' => 'Form MOU',
    // 'card-category' => ' Please complete all the information below to make a MOU'
];