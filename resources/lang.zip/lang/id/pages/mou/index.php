<?php

return [
    'title' => 'MOU',
    'subTitle' => 'Beranda',
    'content' => 'MOU'
];