<?php

return [
    'title' => 'Lihat MOA',
    'subTitle' => 'MOA',
    'category' => 'MOA',
    'content' => 'MOA',

    // 'card-title' => 'Form MOA',
    // 'card-category' => ' Please complete all the information below to make a MOA'
];