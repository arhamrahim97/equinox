<?php

return [
    'title' => 'Tambah MOA',
    'subTitle' => 'MOA',
    'category' => 'MOA',
    'content' => 'MOA',

    'card-title' => 'Formulir MOA',
    'card-category' => 'Silakan lengkapi semua informasi di bawah ini untuk membuat MOA'



];