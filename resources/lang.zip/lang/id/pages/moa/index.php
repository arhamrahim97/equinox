<?php

return [
    'title' => 'MOA',
    'subTitle' => 'Beranda',
    'content' => 'MOA'
];