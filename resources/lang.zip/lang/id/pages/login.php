<?php

return [
    'masuk' => 'Masuk',
    'password' => 'Kata Sandi',
    'gagalLogin' => 'Username atau password salah'
];
