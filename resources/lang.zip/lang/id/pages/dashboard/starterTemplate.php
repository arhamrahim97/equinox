<?php

return [
    'title' => 'Beranda',
    'content' => 'Ini Beranda',
    'subTitle' => 'Beranda'

];