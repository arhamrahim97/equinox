<?php

return [
    'title' => 'Akun',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Tambah Akun',
    'placeHolderTambah' => 'Masukkan Akun',
    'modalTitleUbah' => 'Ubah Akun',
    'role' => 'Role',

    'titleCreate' => 'Tambah',
    'nama' => 'Nama',
    'username' => 'Username',
    'password' => 'Kata Sandi',
    'role' => 'Role',
    'fakultas' => 'Fakultas',
    'prodi' => 'Program Studi',
    'statusAktif' => 'Status Aktif',
    'placeholderNama' => 'Masukkan Nama',
    'placeholderUsername' => 'Masukkan Username',
    'placeholderPassword' => 'Masukkan Kata Sandi',
    'placeholderRole' => 'Pilih Role',
    'placeholderStatusAktif' => 'Pilih Status Aktif',

    'titleEdit' => 'Ubah',
    'notifPassword' => 'Kosongkan jika tidak ingin mengupdate password'
];
