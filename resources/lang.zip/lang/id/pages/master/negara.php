<?php

return [
    'title' => 'Negara',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Tambah Negara',
    'placeHolderTambah' => 'Masukkan Negara',
    'modalTitleUbah' => 'Ubah Negara'
];
