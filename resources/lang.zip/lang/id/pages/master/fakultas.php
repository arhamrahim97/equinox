<?php

return [
    'title' => 'Fakultas',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Tambah Fakultas',
    'placeHolderTambah' => 'Masukkan Fakultas',
    'modalTitleUbah' => 'Ubah Fakultas'
];
