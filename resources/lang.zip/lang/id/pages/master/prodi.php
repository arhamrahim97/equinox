<?php

return [
    'title' => 'Prodi',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Tambah Prodi',
    'placeHolderTambah' => 'Masukkan Prodi',
    'modalTitleUbah' => 'Ubah Prodi',
    'ya' => 'Ya',
    'tidak' => 'Tidak',
    'unitKerja' => 'Unit Kerja',
    'pilihUnit' => 'Pilih status unit kerja'
];
