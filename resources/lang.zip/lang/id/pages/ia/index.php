<?php

return [
    'title' => 'IA',
    'subTitle' => 'Beranda',
    'content' => 'IA'
];