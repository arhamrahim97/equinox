<?php

return [
    'title' => 'Lihat IA',
    'subTitle' => 'IA',
    'category' => 'IA',
    'content' => 'IA',

    // 'card-title' => 'Form IA',
    // 'card-category' => ' Please complete all the information below to make a IA'
];