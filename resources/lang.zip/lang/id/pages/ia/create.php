<?php

return [
    'title' => 'Tambah IA',
    'subTitle' => 'IA',
    'category' => 'IA',
    'content' => 'IA',

    'card-title' => 'Formulir IA',
    'card-category' => 'Silakan lengkapi semua informasi di bawah ini untuk membuat IA'



];