<?php
// Indonesia
return [
    'beranda' => 'Beranda',
    'data_ia' => 'Data IA',
    'data_laporan_lpj' => 'Data Laporan (LPJ)',
    'negara' => 'Negara',
    'fakultas' => 'Fakultas',
    'akun' => 'Akun'
];