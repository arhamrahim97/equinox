<?php

return [
    'required' => ':nama Tidak Boleh Kosong',
    'unique' => ':nama sudah ada',
    'pdf' => ':nama harus berformat file .pdf'
];