<?php

return [
    'placeholderFakultas' => 'Pilih Fakultas',
    'placeholderProdi' => 'Pilih Program Studi',
];
