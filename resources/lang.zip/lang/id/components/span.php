<?php

return [
    'kadaluarsa' => 'Kadaluarsa',
    'aktif' => 'Aktif',
    'masa_tenggang' => 'Masa Tenggang'  
];