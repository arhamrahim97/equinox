<?php

return [
    'aturProfil' => 'Atur Profil',
    'lihatProfil' => 'Lihat Profil',
    'inggris' => 'Inggris (United States)',
    'keluar' => 'Keluar',
];
