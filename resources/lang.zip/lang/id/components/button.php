<?php

return [
    'add' => 'Tambah',
    'view' => '<i class="fas fa-eye"></i> Lihat',
    'save' => 'Simpan',
    'edit' => '<i class="fas fa-edit"></i> Ubah',
    'update' => '<i class="fas fa-save"></i> Perbarui',
    'delete' => '<i class="fas fa-trash"></i> Hapus',    
    'download_document' => '<i class="fas fa-download"></i> Unduh Dokumen'    
];