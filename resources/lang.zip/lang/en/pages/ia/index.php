<?php

return [
    'title' => 'IA',
    'subTitle' => 'Dashboard',
    'content' => 'IA'
];