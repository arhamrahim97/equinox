<?php

return [
    'masuk' => 'Sign in',
    'password' => 'Password',
    'gagalLogin' => 'Username atau password salah'
];
