<?php

return [
    'title' => 'MOA',
    'subTitle' => 'Dashboard',
    'content' => 'MOA'
];