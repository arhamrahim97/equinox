<?php

return [
    'title' => 'MOU',
    'subTitle' => 'Dashboard',
    'content' => 'MOU'
];