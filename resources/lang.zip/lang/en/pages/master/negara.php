<?php

return [
    'title' => 'Country',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Add Country',
    'placeHolderTambah' => 'Enter Country',
    'modalTitleUbah' => 'Update Country'
];
