<?php

return [
    'title' => 'Faculty',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Add Faculty',
    'placeHolderTambah' => 'Enter Faculty',
    'modalTitleUbah' => 'Update Faculty'
];
