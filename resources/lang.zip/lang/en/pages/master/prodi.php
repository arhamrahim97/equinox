<?php

return [
    'title' => 'Study Program',
    'subTitle' => 'Master',
    'modalTitleTambah' => 'Add Study Program',
    'placeHolderTambah' => 'Enter Study Program',
    'modalTitleUbah' => 'Update Study Program',
    'ya' => 'Yes',
    'tidak' => 'No',
    'unitKerja' => 'Work Unit',
    'pilihUnit' => 'Select Work Unit Status'
];
