<?php

return [
    'title' => 'Dashboard',
    'content' => 'This is Dashboard',
    'subTitle' => 'Dashboard'
];