<?php

return [
    'placeholderFakultas' => 'Choose Faculty',
    'placeholderProdi' => 'Choose Study Program',
];
