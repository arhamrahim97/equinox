<?php

return [
    'add' => 'Add',
    'view' => '<i class="fas fa-eye"></i> View',
    'save' => 'Save',
    'edit' => '<i class="fas fa-edit"></i> Edit',
    'update' => '<i class="fas fa-save"></i> Update',
    'delete' => '<i class="fas fa-trash"></i> Delete',    
    'download_document' => '<i class="fas fa-download"></i> Unduh Document'        
];