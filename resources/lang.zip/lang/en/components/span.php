<?php

return [
    'kadaluarsa' => 'Expired',
    'aktif' => 'Actived',
    'masa_tenggang' => 'Grace Period'  
];