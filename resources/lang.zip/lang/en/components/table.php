<?php

return [
    'nomor' => 'Number',
    'username' => 'Username',
    'nama' => 'Name',
    'aksi' => 'Action',
    'unitKerja' => 'Work Unit',
    'role' => 'Role',
    'fakultas' => 'Faculty',
    'prodi' => 'Study Program',

    'alamat' => 'Address',
    'region' => 'Region',
    'negara' => 'Country',
    'provinsi' => 'Province',
    'kota' => 'City',
    'kecamatan' => 'Districts',
    'kelurahan' => 'Village',
    'telepon' => 'Phone',


    'pengusul' => 'Proposer',
    'nomor_mou' => 'MOU Number',
    'nomor_moa' => 'MOA Number',
    'nomor_ia' => 'IA Number',
    'nomor_mou_pengusul' => 'MOU Number of the Proposer',
    'nomor_moa_pengusul' => 'MOA Number of the Proposer',
    'nomor_ia_pengusul' => 'IA Number of the Proposer',
    'tanggal_mulai' => 'Starting Date',
    'tanggal_berakhir' => 'End Date',
];