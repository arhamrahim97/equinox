<?php

return [
    'required' => ':nama Cannot Be Empty',
    'unique' => 'The :nama has already been taken',
    'pdf' => 'The :nama must be in pdf file format'
];