<?php

return [
    'aturProfil' => 'Profile Setting',
    'lihatProfil' => 'View Profile',
    'inggris' => 'England (United States)',
    'keluar' => 'Logout',
];
