<?php
// Inggris
return [
    'beranda' => 'Dashboard',
    'data_ia' => 'Data IA',
    'data_laporan_lpj' => 'Data Reports',
    'negara' => 'Country',
    'fakultas' => 'Faculty',
    'akun' => 'Account'
];